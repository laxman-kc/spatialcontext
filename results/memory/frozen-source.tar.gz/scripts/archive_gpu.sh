#!/usr/bin/env bash
set -euo pipefail
cd /ephemeral/earlier-clip-qa
export PYTHONPATH=.
.venv/bin/python scripts/backup_inventory.py create --root . --inventory /ephemeral/ecqa-backup-inventory.json
.venv/bin/python - <<'PY'
import hashlib
import json
import tarfile
from pathlib import Path
root=Path('/ephemeral/earlier-clip-qa')
inventory=Path('/ephemeral/ecqa-backup-inventory.json')
contents=json.loads(inventory.read_text())
archive=Path('/ephemeral/ecqa-backup.tar.gz')
temporary=archive.with_suffix('.gz.part')
with tarfile.open(temporary,'w:gz',compresslevel=1) as bundle:
    for name in sorted(contents['files']):
        bundle.add(root/name,arcname='earlier-clip-qa/'+name,recursive=False)
    bundle.add(inventory,arcname='backup-inventory.json',recursive=False)
temporary.replace(archive)
hasher=hashlib.sha256()
with archive.open('rb') as handle:
    for chunk in iter(lambda:handle.read(1024*1024),b''):
        hasher.update(chunk)
receipt={'archive':archive.name,'bytes':archive.stat().st_size,'sha256':hasher.hexdigest(),
         'file_count':contents['file_count'],'uncompressed_bytes':contents['total_bytes']}
Path('/ephemeral/ecqa-backup-receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps(receipt,indent=2))
PY
